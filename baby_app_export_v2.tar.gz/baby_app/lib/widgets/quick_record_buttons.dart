import 'package:flutter/material.dart';

class QuickRecordButtons extends StatelessWidget {
  const QuickRecordButtons({super.key});

  final List<Map<String, dynamic>> buttons = const [
    {'icon': '🍼', 'label': '喂奶', 'color': Color(0xFFFFCCBC)},
    {'icon': '😴', 'label': '睡觉', 'color': Color(0xFFB2DFDB)},
    {'icon': '🥄', 'label': '辅食', 'color': Color(0xFFFFF9C4)},
    {'icon': '💩', 'label': '排便', 'color': Color(0xFFD7CCC8)},
    {'icon': '🌡️', 'label': '体温', 'color': Color(0xFFFFCDD2)},
    {'icon': '📷', 'label': '拍照', 'color': Color(0xFFE1BEE7)},
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '⚡ 快捷记录',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: buttons.sublist(0, 3).map((btn) => _buildButton(btn)).toList(),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: buttons.sublist(3, 6).map((btn) => _buildButton(btn)).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildButton(Map<String, dynamic> btn) {
    return GestureDetector(
      onTap: () {},
      child: Column(
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: btn['color'] as Color,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: (btn['color'] as Color).withOpacity(0.4),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Center(
              child: Text(
                btn['icon'] as String,
                style: const TextStyle(fontSize: 32),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            btn['label'] as String,
            style: TextStyle(
              fontSize: 13,
              color: Colors.grey[700],
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}
