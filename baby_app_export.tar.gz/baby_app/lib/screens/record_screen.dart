import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';

class RecordScreen extends StatefulWidget {
  const RecordScreen({super.key});

  @override
  State<RecordScreen> createState() => _RecordScreenState();
}

class _RecordScreenState extends State<RecordScreen> {
  CalendarFormat _calendarFormat = CalendarFormat.week;
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            // 日历
            SliverToBoxAdapter(
              child: Container(
                margin: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: TableCalendar(
                  firstDay: DateTime.utc(2024, 1, 1),
                  lastDay: DateTime.utc(2025, 12, 31),
                  focusedDay: _focusedDay,
                  calendarFormat: _calendarFormat,
                  selectedDayPredicate: (day) {
                    return isSameDay(_selectedDay, day);
                  },
                  onDaySelected: (selectedDay, focusedDay) {
                    setState(() {
                      _selectedDay = selectedDay;
                      _focusedDay = focusedDay;
                    });
                  },
                  onFormatChanged: (format) {
                    setState(() {
                      _calendarFormat = format;
                    });
                  },
                  headerStyle: const HeaderStyle(
                    titleCentered: true,
                    formatButtonVisible: false,
                    leftChevronIcon: Icon(Icons.chevron_left, color: Color(0xFFFF8A80)),
                    rightChevronIcon: Icon(Icons.chevron_right, color: Color(0xFFFF8A80)),
                    titleTextStyle: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFFF8A80),
                    ),
                  ),
                  calendarStyle: CalendarStyle(
                    todayDecoration: BoxDecoration(
                      color: const Color(0xFFFF8A80).withOpacity(0.3),
                      shape: BoxShape.circle,
                    ),
                    selectedDecoration: const BoxDecoration(
                      color: Color(0xFFFF8A80),
                      shape: BoxShape.circle,
                    ),
                    markerDecoration: const BoxDecoration(
                      color: Color(0xFF80CBC4),
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              ),
            ),

            // 今日相册
            SliverToBoxAdapter(
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 16),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          '📸 今日相册',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFFF3E0),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Text(
                            '5张',
                            style: TextStyle(
                              fontSize: 12,
                              color: Color(0xFFFF8A80),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      height: 80,
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        children: [
                          _buildPhotoThumbnail('早', const Color(0xFFFFE0B2)),
                          _buildPhotoThumbnail('中', const Color(0xFFFFCCBC)),
                          _buildPhotoThumbnail('辅', const Color(0xFFFFF9C4)),
                          _buildPhotoThumbnail('睡', const Color(0xFFB2DFDB)),
                          _buildPhotoThumbnail('晚', const Color(0xFFE1BEE7)),
                          _buildAddPhotoButton(),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // 时间轴标题
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 24, 16, 12),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      '⏰ 今日时间轴',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFF8A80).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.add,
                            size: 16,
                            color: Color(0xFFFF8A80),
                          ),
                          SizedBox(width: 4),
                          Text(
                            '记一笔',
                            style: TextStyle(
                              fontSize: 12,
                              color: Color(0xFFFF8A80),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // 时间轴列表
            SliverList(
              delegate: SliverChildListDelegate([
                _buildTimelineItem(
                  time: '15:30',
                  icon: '🍼',
                  title: '奶粉',
                  detail: '120ml',
                  color: const Color(0xFFFFCCBC),
                ),
                _buildTimelineItem(
                  time: '14:00',
                  icon: '💩',
                  title: '排便',
                  detail: '正常 · 黄色',
                  color: const Color(0xFFD7CCC8),
                ),
                _buildTimelineItem(
                  time: '12:00',
                  icon: '🥄',
                  title: '辅食',
                  detail: '米粉+南瓜泥 · 吃了大半碗',
                  color: const Color(0xFFFFF9C4),
                  hasPhoto: true,
                  photoCount: 2,
                  hasVideo: true,
                ),
                _buildTimelineItem(
                  time: '09:30',
                  icon: '😴',
                  title: '小睡',
                  detail: '09:30-11:00 · 1.5小时',
                  color: const Color(0xFFB2DFDB),
                ),
                _buildTimelineItem(
                  time: '08:00',
                  icon: '🍼',
                  title: '母乳亲喂',
                  detail: '15分钟 · 左边',
                  color: const Color(0xFFFFCCBC),
                ),
                _buildTimelineItem(
                  time: '07:30',
                  icon: '🌅',
                  title: '起床',
                  detail: '睡眼惺忪的小可爱',
                  color: const Color(0xFFFFF9C4),
                  hasPhoto: true,
                  photoCount: 1,
                ),
                const SizedBox(height: 20),
              ]),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPhotoThumbnail(String label, Color color) {
    return Container(
      width: 72,
      height: 72,
      margin: const EdgeInsets.only(right: 10),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Center(
        child: Text(
          label,
          style: TextStyle(
            fontSize: 20,
            color: Colors.grey[700],
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }

  Widget _buildAddPhotoButton() {
    return Container(
      width: 72,
      height: 72,
      margin: const EdgeInsets.only(right: 10),
      decoration: BoxDecoration(
        color: const Color(0xFFF5F5F5),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.grey[300]!,
          style: BorderStyle.solid,
        ),
      ),
      child: const Center(
        child: Icon(
          Icons.add,
          color: Colors.grey,
          size: 28,
        ),
      ),
    );
  }

  Widget _buildTimelineItem({
    required String time,
    required String icon,
    required String title,
    required String detail,
    required Color color,
    bool hasPhoto = false,
    int photoCount = 0,
    bool hasVideo = false,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 50,
            child: Text(
              time,
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey[500],
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Text(
                icon,
                style: const TextStyle(fontSize: 24),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  detail,
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.grey[600],
                  ),
                ),
                if (hasPhoto || hasVideo) ...[
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      if (hasPhoto)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          margin: const EdgeInsets.only(right: 8),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFFF3E0),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(
                                Icons.photo,
                                size: 14,
                                color: Color(0xFFFF8A80),
                              ),
                              const SizedBox(width: 4),
                              Text(
                                '$photoCount张',
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: Color(0xFFFF8A80),
                                ),
                              ),
                            ],
                          ),
                        ),
                      if (hasVideo)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: const Color(0xFFE8F5E9),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.videocam,
                                size: 14,
                                color: Color(0xFF66BB6A),
                              ),
                              SizedBox(width: 4),
                              Text(
                                '视频',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Color(0xFF66BB6A),
                                ),
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
